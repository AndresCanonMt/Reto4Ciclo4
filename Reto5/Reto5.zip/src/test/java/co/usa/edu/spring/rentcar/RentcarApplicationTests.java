package co.usa.edu.spring.rentcar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentcarApplicationTests {

	@Test
	void contextLoads() {
	}

}
